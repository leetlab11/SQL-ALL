-- use WHERE and OR for condition

select name, population, area
from World
where area >= 3000000 or population >= 25000000


-- apple- 3
-- google- 2
-- bloomberg- 2
-- amazon- 2
-- adobe- 3
-- facebook- 3
-- yahoo- 2
